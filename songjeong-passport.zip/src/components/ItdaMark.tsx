// "잇다" 브랜드 마크 — 두 점을 잇는 곡선. 보고서에서 제안한 심볼 컨셉을 SVG로 구현.
export default function ItdaMark({ size = 28, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" className={className}>
      <circle cx="8" cy="22" r="4" fill="currentColor" opacity="0.55" />
      <circle cx="24" cy="10" r="4" fill="currentColor" />
      <path d="M10 20 Q 16 8 22 11" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" fill="none" />
    </svg>
  );
}
